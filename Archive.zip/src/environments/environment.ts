export const APP_CONFIG = {
  production: false,
  environment: 'LOCAL'
};
